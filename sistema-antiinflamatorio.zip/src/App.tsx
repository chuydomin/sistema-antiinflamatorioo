import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  ShieldCheck, 
  ChevronDown, 
  Clock, 
  ShoppingBag, 
  Gift, 
  Target, 
  BookOpen, 
  Zap, 
  XCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react';

const CTA_URL = "https://pay.hotmart.com/L105785496G";

const Section = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <section className={`py-16 md:py-24 px-5 md:px-10 max-w-7xl mx-auto w-full ${className}`}>
    {children}
  </section>
);

const CTAButton = ({ text, secondary = false, className = "" }: { text: string, secondary?: boolean, className?: string }) => (
  <motion.a
    href={CTA_URL}
    whileHover={{ scale: 1.05, boxShadow: "0 15px 35px rgba(94, 122, 107, 0.3)" }}
    whileTap={{ scale: 0.95 }}
    className={`
      inline-flex flex-col items-center justify-center text-center px-10 py-6 rounded-full font-display font-bold text-lg md:text-xl transition-all duration-300
      ${secondary 
        ? "bg-linear-to-r from-accent to-[#b08d4b] text-white shadow-xl" 
        : "bg-linear-to-r from-primary to-primary-dark text-white shadow-xl glow-soft"
      }
      ${className}
    `}
  >
    <span>{text}</span>
    <span className="text-xs mt-1 font-sans font-medium opacity-80">Acceso instantáneo - Descarga inmediata</span>
  </motion.a>
);

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className={`mb-4 border-2 transition-colors duration-300 rounded-3xl ${isOpen ? 'border-primary bg-primary/5' : 'border-gray-100 bg-white shadow-sm'}`}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-6 text-left font-display font-bold md:text-lg text-text-main"
      >
        <span>{question}</span>
        <ChevronDown className={`transition-transform duration-300 shadow-sm ${isOpen ? 'rotate-180 text-primary' : 'text-gray-400'}`} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-6 pt-0 text-text-muted font-sans leading-relaxed">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function App() {
  const [timeLeft, setTimeLeft] = useState({ h: 24, m: 59, s: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { h, m, s } = prev;
        if (s > 0) s--;
        else {
          s = 59;
          if (m > 0) m--;
          else {
            m = 59;
            if (h > 0) h--;
          }
        }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-bg-base selection:bg-primary/20 text-text-main">
      {/* Sticky Bottom Bar on Mobile */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-gray-100 p-4 flex justify-center">
        <a 
          href={CTA_URL}
          className="w-full bg-linear-to-r from-primary to-primary-dark text-white py-4 rounded-full font-display font-bold text-center text-sm shadow-xl"
        >
          SÍ, QUIERO MI DESCUENTO
        </a>
      </div>

      {/* Hero Section */}
      <header className="relative pt-12 pb-16 md:pt-24 md:pb-32 overflow-hidden flex flex-col items-center">
        <div className="absolute inset-0 bg-radial-[at_50%_0%] from-primary/5 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-5 text-center relative z-10 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 relative inline-block mx-auto"
          >
            <img 
              src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=1200" 
              className="w-full max-w-4xl h-[300px] md:h-[450px] object-cover rounded-[2rem] md:rounded-[3.5rem] shadow-2xl border-4 border-white"
              referrerPolicy="no-referrer"
              alt="Healthy life mockup"
            />
            <div className="absolute -bottom-6 -right-6 md:-bottom-10 md:-right-10 bg-white p-4 md:p-6 rounded-3xl shadow-2xl flex items-center gap-4 border border-gray-100 animate-pulse-soft">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                <Sparkles className="text-primary w-6 h-6 md:w-8 md:h-8" />
              </div>
              <div className="text-left">
                <p className="text-primary font-display font-black text-xl md:text-2xl leading-none">5,000+</p>
                <p className="text-text-muted text-[10px] md:text-xs font-bold uppercase tracking-widest">Mujeres listas</p>
              </div>
            </div>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-extrabold mb-8 text-primary leading-tight max-w-5xl mx-auto"
          >
            Desinflama Tu Cuerpo y Consigue un Abdomen Plano en Solo 14 Días...
          </motion.h1>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl md:text-2xl text-accent font-sans font-medium mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            "Descubre el Sistema de Nutrición Progresiva que cura tu cuerpo sin renunciar al placer de comer"
          </motion.h2>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col items-center gap-6"
          >
            <CTAButton text="🔥 QUIERO MI ACCESO INMEDIATO POR SOLO $11" />
            <div className="flex items-center gap-2 text-text-muted text-sm font-medium">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span>Garantía de satisfacción de 30 días</span>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Intro Section */}
      <Section className="bg-white">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=800" 
              className="rounded-[3rem] w-full h-[500px] object-cover shadow-2xl"
              referrerPolicy="no-referrer"
              alt="Lifestyle health"
            />
            <div className="absolute inset-0 rounded-[3rem] bg-primary/10" />
          </div>
          <div className="text-lg leading-relaxed text-text-muted">
            <p className="mb-6 font-display font-bold text-text-main text-2xl leading-snug">
              ¿Te despiertas cada mañana sintiendo que tu cuerpo no te pertenece?
            </p>
            <p className="mb-6">
              La hinchazón abdominal no es solo un problema estético. Es el grito de auxilio de un sistema digestivo saturado y un cuerpo luchando contra la inflamación silenciosa.
            </p>
            <p className="mb-8 italic border-l-4 border-accent pl-6 py-2">
              "El problema no es tu edad, ni tu metabolismo... es la inflamación crónica que bloquea tus resultados."
            </p>
            
            <div className="bg-bg-base p-10 rounded-[2.5rem] border border-gray-100 shadow-sm">
              <h3 className="text-primary font-display text-2xl mb-4">La Propuesta Real:</h3>
              <p className="text-text-main leading-relaxed">
                Nuestro sistema cura desde adentro. No es una dieta restrictiva; es una guía de nutrición celular que resetea tu inflamación en solo dos semanas.
              </p>
            </div>
          </div>
        </div>
      </Section>

      {/* Benefits Section */}
      <Section className="bg-bg-base">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl mb-10 leading-tight text-text-main">Lo que recuperarás con <span className="text-primary italic">nuestro sistema:</span></h2>
            <ul className="space-y-6">
              {[
                "Abdomen visiblemente suave en 14 días",
                "Claridad mental y energía estable",
                "Adiós a las digestiones pesadas",
                "Equilibrio hormonal natural para 35+",
                "Recetas que amarás compartir con tu familia",
                "Un plan que se adapta a tu estilo de vida"
              ].map((item, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center gap-5 text-lg text-text-muted"
                >
                  <div className="bg-primary/10 p-1 rounded-full">
                    <CheckCircle2 className="text-primary w-6 h-6" />
                  </div>
                  <span>{item}</span>
                </motion.li>
              ))}
            </ul>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img 
              src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=400" 
              className="rounded-3xl w-full h-48 object-cover shadow-lg border-2 border-white"
              referrerPolicy="no-referrer"
              alt="Health food"
            />
            <img 
              src="https://images.unsplash.com/photo-1545209110-046091d0ad58?auto=format&fit=crop&q=80&w=400" 
              className="rounded-3xl w-full h-48 object-cover shadow-lg mt-8 border-2 border-white"
              referrerPolicy="no-referrer"
              alt="Yoga session"
            />
            <img 
              src="https://images.unsplash.com/photo-1552196563-55cd4e45efb3?auto=format&fit=crop&q=80&w=400" 
              className="rounded-3xl w-full h-48 object-cover shadow-lg border-2 border-white"
              referrerPolicy="no-referrer"
              alt="Healthy life"
            />
            <img 
              src="https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&q=80&w=400" 
              className="rounded-3xl w-full h-48 object-cover shadow-lg mt-8 border-2 border-white"
              referrerPolicy="no-referrer"
              alt="Fruit juice"
            />
          </div>
        </div>
      </Section>

      {/* Testimonials */}
      <Section className="bg-white">
        <h2 className="text-center text-3xl md:text-5xl mb-20 text-primary">Mujeres que han cambiado <span className="text-accent underline decoration-accent/20 underline-offset-8 italic">sus vidas</span></h2>
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <motion.div 
            whileHover={{ y: -10 }}
            className="bg-bg-base p-10 rounded-[3rem] border border-gray-100 shadow-xl relative"
          >
            <div className="flex items-center gap-4 mb-8">
              <img 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400" 
                className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md"
                referrerPolicy="no-referrer"
                alt="Maria Elena"
              />
              <div>
                <p className="font-display font-black text-lg text-text-main">María Elena</p>
                <p className="text-accent text-sm font-bold">42 años</p>
              </div>
            </div>
            <p className="italic text-text-main text-lg mb-6 leading-relaxed">"En 14 días perdí 4 cm de cintura y por primera vez en años me siento con energía todo el día. ¡Las recetas son deliciosas!"</p>
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map(i => <Sparkles key={i} className="w-4 h-4 text-accent fill-accent" />)}
            </div>
          </motion.div>
          
          <motion.div 
            whileHover={{ y: -10 }}
            className="bg-bg-base p-10 rounded-[3rem] border border-gray-100 shadow-xl relative"
          >
            <div className="flex items-center gap-4 mb-8">
              <img 
                src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400" 
                className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-md"
                referrerPolicy="no-referrer"
                alt="Carmen"
              />
              <div>
                <p className="font-display font-black text-lg text-text-main">Carmen</p>
                <p className="text-accent text-sm font-bold">48 años</p>
              </div>
            </div>
            <p className="italic text-text-main text-lg mb-6 leading-relaxed">"Pensé que la fatiga era parte de la menopausia, pero con este sistema recuperé mi cuerpo y mi confianza. ¡Es increíble!"</p>
            <div className="flex items-center gap-1">
              {[1,2,3,4,5].map(i => <Sparkles key={i} className="w-4 h-4 text-accent fill-accent" />)}
            </div>
          </motion.div>
        </div>
      </Section>

      {/* Red Flags / Who it is NOT for */}
      <Section className="bg-urgent/5 border-y border-urgent/10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl md:text-4xl text-center mb-12 font-display text-urgent">
             ❌ Este camino NO es para ti si:
          </h2>
          <div className="grid md:grid-cols-2 gap-8 text-left">
            {[
              "Buscas una dieta milagro de un solo día",
              "No estás dispuesta a priorizar tu salud 14 días",
              "Prefieres químicos antes que alimentos naturales",
              "Odias comer rico y saludable al mismo tiempo"
            ].map((item, i) => (
              <div key={i} className="flex gap-4 items-center p-6 bg-white rounded-3xl shadow-sm border border-urgent/10">
                <XCircle className="text-urgent w-6 h-6 flex-shrink-0" />
                <span className="text-text-main font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* Deliverables & Bonuses */}
      <Section id="pricing" className="bg-white">
        <h2 className="text-center text-4xl md:text-5xl mb-20 text-text-main">Contenido del <span className="text-primary italic">Programa Especial</span></h2>
        
        <div className="grid md:grid-cols-2 gap-12 mb-20 max-w-6xl mx-auto">
          <div className="bg-bg-base p-1 md:p-2 rounded-[3.5rem] shadow-2xl overflow-hidden group border border-gray-100 italic">
            <img 
              src="https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&q=80&w=600" 
              className="w-full h-80 object-cover rounded-[3rem] mb-8"
              referrerPolicy="no-referrer"
              alt="Planner mockup"
            />
            <div className="px-8 pb-10">
              <div className="flex items-center gap-4 mb-4">
                <Target className="w-8 h-8 text-primary" />
                <h3 className="text-2xl font-black text-text-main">Planificador 14 Días</h3>
              </div>
              <p className="text-text-muted leading-relaxed">Guía paso a paso con las comidas, los horarios y los hábitos exactos para desinflamar tu cuerpo.</p>
            </div>
          </div>
          
          <div className="bg-bg-base p-1 md:p-2 rounded-[3.5rem] shadow-2xl overflow-hidden group border border-gray-100 italic">
            <img 
              src="https://images.unsplash.com/photo-1505252585461-04db1eb84625?auto=format&fit=crop&q=80&w=600" 
              className="w-full h-80 object-cover rounded-[3rem] mb-8"
              referrerPolicy="no-referrer"
              alt="Recipes book"
            />
            <div className="px-8 pb-10">
              <div className="flex items-center gap-4 mb-4">
                <BookOpen className="w-8 h-8 text-primary" />
                <h3 className="text-2xl font-black text-text-main">Recetario Anticurativo</h3>
              </div>
              <p className="text-text-muted leading-relaxed">Más de 50 platos gourmet saludables que se preparan en menos de 20 minutos.</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {[
            { tag: "BONO #1", title: "Lista Maestra de Compras", icon: <ShoppingBag /> },
            { tag: "BONO #2", title: "Planificador Imprimible", icon: <Gift /> },
            { tag: "BONO #3", title: "30 Batidos Flash", icon: <Zap /> }
          ].map((bonus, i) => (
            <motion.div 
              key={i} 
              whileHover={{ y: -5 }}
              className="bg-white p-10 rounded-[2.5rem] border border-gray-100 flex flex-col items-center text-center shadow-lg relative"
            >
              <div className="absolute -top-4 bg-accent text-white py-1 px-4 rounded-full text-[10px] font-black uppercase tracking-widest">{bonus.tag}</div>
              <div className="text-primary mb-6 scale-150 p-4 bg-primary/5 rounded-full">{bonus.icon}</div>
              <h4 className="font-display font-bold text-xl mb-4 text-text-main">{bonus.title}</h4>
              <p className="text-sm text-text-muted/60 mb-2 line-through font-bold">Valor: $47 - $67</p>
              <p className="text-primary font-black uppercase text-sm tracking-tighter">¡GRATIS HOY!</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Pricing Stake */}
      <Section className="text-center pt-0">
        <div className="max-w-3xl mx-auto bg-white rounded-[4rem] p-16 border border-gray-100 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16" />
          <p className="text-text-muted mb-6 font-display font-bold uppercase tracking-[0.2em] text-xs">Oportunidad Única</p>
          <div className="flex flex-col items-center mb-10">
            <span className="text-4xl text-text-muted/30 line-through mb-2">$251</span>
            <span className="text-8xl md:text-9xl font-display font-black text-primary">$11</span>
            <div className="h-1 w-20 bg-accent/30 rounded-full mt-4" />
          </div>
          
          <CTAButton text="🔥 SÍ, QUIERO MI OFERTA ESPECIAL" className="w-full max-w-md" />
          
          <p className="mt-8 text-text-muted font-medium text-sm flex items-center justify-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            Acceso de por vida | Un solo pago
          </p>
        </div>
      </Section>

      {/* Guarantee Section */}
      <Section className="bg-white overflow-hidden relative">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-16 relative z-10">
          <div className="relative">
            <div className="w-56 h-56 md:w-80 md:h-80 rounded-[4rem] bg-linear-to-br from-primary to-primary-dark p-1.5 shadow-2xl rotate-3">
               <div className="w-full h-full rounded-[3.8rem] bg-white flex items-center justify-center flex-col text-center p-10">
                  <ShieldCheck className="w-20 h-20 text-primary mb-4" />
                  <span className="font-display font-black text-5xl text-primary -mb-1">30</span>
                  <span className="font-sans font-bold text-xs uppercase tracking-tighter text-text-muted">Días de Respaldo</span>
               </div>
            </div>
          </div>
          <div className="text-center md:text-left flex-1">
            <h2 className="text-4xl md:text-5xl text-primary font-black mb-8 leading-tight">TU TRANQUILIDAD ES <span className="text-accent italic">PRIMERO</span></h2>
            <p className="text-xl text-text-muted leading-relaxed mb-8">
              No quiero tu dinero si no estás viendo una transformación real. Sé que esto funciona, por eso absorbo todo el riesgo.
            </p>
            <p className="text-text-main font-bold p-6 bg-bg-base rounded-3xl border border-gray-100">
              "Si en 30 días no sientes tu cuerpo más liviano y desinflamado, te devuelvo hasta el último centavo. Sin condiciones."
            </p>
          </div>
        </div>
      </Section>

      {/* FAQ Accordion */}
      <Section>
        <h2 className="text-center text-3xl md:text-4xl mb-12">Preguntas Frecuentes</h2>
        <div className="max-w-3xl mx-auto">
          <FAQItem 
            question="¿Funciona si tengo más de 50 años?" 
            answer="¡Absolutamente! Este sistema está diseñado específicamente para mujeres de 35+ años y es especialmente efectivo para regular el sistema metabólico y hormonal, incluso durante la menopausia." 
          />
          <FAQItem 
            question="¿Son ingredientes caros o difíciles de conseguir?" 
            answer="No. Todo lo que incluimos en el recetario se encuentra en cualquier supermercado común de barrio. Priorizamos la simplicidad y el ahorro." 
          />
          <FAQItem 
            question="¿Cuánto tiempo necesito cocinar cada día?" 
            answer="Maximo 20-30 minutos. Entendemos que eres una mujer ocupada, por lo que las recetas son de preparación rápida o admiten preparación por lotes (batch cooking)." 
          />
          <FAQItem 
            question="¿Qué pasa si no funciona para mí?" 
            answer="Tienes una garantía de hierro de 30 días. Si aplicas el plan y sientes que no es lo que esperabas, nos escribes y te devolvemos el 100% de tu dinero." 
          />
        </div>
      </Section>

      {/* Urgency Section */}
      <Section className="bg-urgent/10 border-y border-urgent/20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-display text-urgent mb-10 flex items-center justify-center gap-4">
            <Clock className="w-8 h-8 animate-pulse text-urgent" />
            OFERTA ÚNICA
          </h2>
          <div className="flex justify-center gap-4 mb-10">
            <div className="bg-white p-6 rounded-[2rem] min-w-[90px] shadow-lg border border-urgent/10">
              <span className="text-4xl font-mono font-bold text-urgent">{timeLeft.h.toString().padStart(2, '0')}</span>
              <span className="block text-[10px] text-text-muted font-bold mt-1">HORAS</span>
            </div>
            <div className="bg-white p-6 rounded-[2rem] min-w-[90px] shadow-lg border border-urgent/10">
              <span className="text-4xl font-mono font-bold text-urgent">{timeLeft.m.toString().padStart(2, '0')}</span>
              <span className="block text-[10px] text-text-muted font-bold mt-1">MINUTOS</span>
            </div>
            <div className="bg-white p-6 rounded-[2rem] min-w-[90px] shadow-lg border border-urgent/10">
              <span className="text-4xl font-mono font-bold text-urgent">{timeLeft.s.toString().padStart(2, '0')}</span>
              <span className="block text-[10px] text-text-muted font-bold mt-1">SEGUNDOS</span>
            </div>
          </div>
          <p className="text-text-main font-bold italic mb-4">
            "Este precio de $11 es exclusivo para las próximas 200 inscritas."
          </p>
          <div className="w-full bg-gray-200 h-3 rounded-full overflow-hidden max-w-sm mx-auto">
             <motion.div 
               initial={{ width: "95%" }}
               animate={{ width: "98%" }}
               transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
               className="bg-urgent h-full" 
             />
          </div>
          <p className="text-xs text-text-muted mt-2">Cupos casi agotados (98% completos)</p>
        </div>
      </Section>

      {/* Final CTA */}
      <Section className="py-32 text-center bg-radial-[at_50%_100%] from-primary/5 to-transparent relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1 bg-linear-to-r from-transparent via-gray-100 to-transparent" />
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           className="max-w-5xl mx-auto"
        >
          <h2 className="text-5xl md:text-7xl mb-10 leading-none tracking-tighter">
            TU <span className="text-primary font-black">NUEVA VIDA</span> COMIENZA AQUÍ
          </h2>
          <p className="text-2xl md:text-3xl text-text-muted mb-16 italic font-medium max-w-3xl mx-auto leading-relaxed">
            "En un año mirarás atrás y agradecerás haber tomado esta decisión hoy. ¿Te unes?"
          </p>
          <CTAButton text="SÍ, QUIERO MI TRANSFORMACIÓN AHORA" className="scale-110 !px-16 !py-8 shadow-2xl" />
          
          <div className="mt-16 flex flex-wrap justify-center gap-10 text-text-muted font-bold text-sm tracking-widest uppercase">
             <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-primary" />
                <span>Pago Blindado</span>
             </div>
             <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-primary" />
                <span>Instantáneo</span>
             </div>
             <div className="flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-primary" />
                <span>30 Días Garantía</span>
             </div>
          </div>
        </motion.div>
      </Section>

      {/* Footer */}
      <footer className="py-20 bg-white border-t border-gray-100 text-center text-text-muted text-sm px-5">
        <div className="max-w-7xl mx-auto">
          <p className="mb-6">© {new Date().getFullYear()} Sistema Antiinflamatorio Progresivo. Elaborado con amor para tu salud.</p>
          <p className="max-w-4xl mx-auto mb-10 opacity-60 text-xs leading-relaxed">
            IMPORTANTE: Los resultados pueden variar. Esta información no reemplaza el diagnóstico de un profesional de la salud. Todas las estrategias nutricionales deben ser supervisadas por un experto titulado.
          </p>
          <div className="flex justify-center gap-10 font-bold uppercase tracking-widest text-[10px]">
            <a href="#" className="hover:text-primary transition-colors">Privacidad</a>
            <a href="#" className="hover:text-primary transition-colors">Términos</a>
            <a href="#" className="hover:text-primary transition-colors">Soporte</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
